import datetime
import os
print("Hello World!")
print(datetime.datetime.now())
print(os.environ)