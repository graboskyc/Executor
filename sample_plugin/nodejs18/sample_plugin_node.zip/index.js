console.log("Hello World");
console.log(process.env);