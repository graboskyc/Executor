import datetime

print("Hello World!")
print(datetime.datetime.now())